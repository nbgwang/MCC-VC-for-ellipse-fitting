a = 3;
b = 10;

params.a = a;
params.b = b;