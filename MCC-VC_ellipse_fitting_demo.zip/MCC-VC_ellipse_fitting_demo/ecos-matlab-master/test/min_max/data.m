a = 0.5;
b = 5;

params.a = a;
params.b = b;