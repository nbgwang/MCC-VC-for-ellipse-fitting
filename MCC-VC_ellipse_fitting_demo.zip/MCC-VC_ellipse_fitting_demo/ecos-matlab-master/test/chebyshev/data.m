a1 = [ 2;  1];
a2 = [ 2; -1];
a3 = [-1;  2];
a4 = [-1; -2];
b = ones(4,1);

a1t = a1';
a2t = a2';
a3t = a3';
a4t = a4';

b1 = b(1);
b2 = b(2);
b3 = b(3);
b4 = b(4);

na1 = norm(a1);
na2 = norm(a2);
na3 = norm(a3);
na4 = norm(a4);

params.a1t = a1t;
params.a2t = a2t;
params.a3t = a3t;
params.a4t = a4t;
params.b = b;

params.b1 = b1;
params.b2 = b2;
params.b3 = b3;
params.b4 = b4;

params.na1 = na1;
params.na2 = na2;
params.na3 = na3;
params.na4 = na4;
