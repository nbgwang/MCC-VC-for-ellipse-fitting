function [Par]=EF_MCCVC_LP(n)
warning off
%--------------------------------------------------------
%Robust ellipse fitting by MCC-VC
%
%Attention! This function requires the ECOS solver,
%so please add folder "ecos-matlab-master" containing the ECOS solver to 
%the preset path of your MATLAB.
%----------------------------
%Inputs:
%----------------------------
%n:              6xN    input data points
%n(:,i)= [xx(i)^2 xx(i)*yy(i) yy(i)^2 xx(i) yy(i) 1].';
%----------------------------
%Output:
%----------------------------
%Par:            1x6    [A B C D E F]  ellipse parameters
%--------------------------------------------------------
N_n=length(n);
epsilon=1e-2;
c=0;
Iti=50;
It=50;
ww = -ones(1,N_n);
w = -ww/sum(ww);

%% Use the subproblem of MCC to estimate an initial ellipse parameters
[v0]=MCC_vc_ECOS(n,N_n,c,epsilon,w);
data_points = v0.'*n;

%% Outer loop
for it=1:It
    %% Estimated sigma and c
    
    sigma1=estimate_sgm(data_points,c);
    
    c=estimate_c(data_points,sigma1);
    
    %% Estimating ellipse parameters
    
    ww = -exp(-abs(data_points-c)/sigma1);
    
    w = -ww/sum(ww);
    
    for iti=1:Iti
        [v]=MCC_vc_ECOS(n,N_n,c,epsilon,w);
        data_points = v.'*n;
        ww = -exp(-abs(data_points-c)/sigma1);
        w = -ww/sum(ww);
        if norm(v-v0)<1e-5
            break;
        else
            v0=v;
        end
    end
    
    %% Outer loop termination condition setting
    if it==1
        T0=1/(4*sigma1)-(1/(N_n*sigma1))*sum(exp(-abs(data_points-c)/sigma1));
    else
        T=1/(4*sigma1)-(1/(N_n*sigma1))*sum(exp(-abs(data_points-c)/sigma1));
        if (abs(T-T0)<1e-5)
            break;
        end
        T0=T;
    end
    data_points = v.'*n;
end
Par=v;
end



%% Function for search sgm
function  [sgm]=estimate_sgm(data_points,c)
b=abs(data_points-c);
N=length(b);
r0=0;
for i=1:50
    b1=sum(exp(-b.*r0))/N;b2=sum(b.*exp(-b.*r0))/N;
    b3=sum((b.^2).*exp(-b.*r0))/N;b4=sum((b.^3).*exp(-b.*r0))/N;
    d1=2*b4/3;d2=-3*b3/2;d3=2*b2;d4=1/4-b1+b2*r0;
    A=d2^2-3*d1*d3;
    B=d2*d3-9*d1*d4;
    C=d3^2-3*d2*d4;
    Y1=A*d2+3*d1*((-B+sqrt(B^2-4*A*C))/2);
    Y2=A*d2+3*d1*((-B-sqrt(B^2-4*A*C))/2);
    r1=(-d2-(nthroot(Y1,3)+nthroot(Y2,3)))/(3*d1);
    if norm(r1-r0)<1e-5
        r0=r1;
        break
    end
    r0=r1;
end
sgm=1/r0;
end

%% Function for Estimate_c( for search c )
function  c1=estimate_c(data,sgm)
fa=@(c) (sum((abs(data-c)/sgm)));
c0= fminsearch(fa,0);
data=sort(data);

a1=abs(data)-abs(c0);
[~,inx]=min(a1);
Inx_val=[inx-1,inx,inx+1];

if  inx==length(data)
    Inx_val=[inx-2,inx-1,inx];
end

if inx==1
    Inx_val=[inx,inx+1,inx+2];
end

for i=1:3
    Inx_val(2,i)=-sum(exp(-(abs(data-data(Inx_val(1,i))))/sgm));
end
a2=zeros(1,length(data));
for n=1:length(data)
    a2(n)=-sum(exp(-(abs(data-data(n)))/sgm));
end

if Inx_val(2,1)>Inx_val(2,2)
    u_p=Inx_val(1,1);
    for ii=u_p+1:length(data)-1
        if a2(ii)<a2(ii+1)
            l_p=ii+1;
            break
        end
    end
else
    if Inx_val(2,1)<Inx_val(2,2)
        l_p=Inx_val(1,3);
        for ii=l_p-1:-1:1
            if a2(ii)<a2(ii-1)
                u_p=ii-1;
                break
            end
        end
    end
    
end

if Inx_val(2,1)==Inx_val(2,2)
    u_p=inx-1;l_p=inx+1;
end
fc=@(c)  -sum(exp(-(abs(data-c))/sgm));
if abs(data(u_p))-abs(data(l_p))>1e-5
    c1=bisection(fc,data(u_p),data(l_p),1e-5,data,sgm);
else
    c1=c0;
end
end

function [c]=bisection(f,a,b,esp,data,sgm)
syms x;
while b-a > esp
    m = (b+a)/2;
    dao = f_1(data,sgm,m);
    if dao == 0
        k = m;
        y = subs(f,x,m);
        break;
    else
        if(dao<0)
            a = m;
        else
            b = m;
        end
    end
    if b-a<=esp
        c =(b+a)/2;
    end
end
end

function value=f_1(data,sgm,x)
for i=1:length(data)
    if  x<data(i)
        f_1(i)=-(1/sgm)*exp((x-data(i))/sgm);
    else
        if x==data(i)
            f_1(i)=0;
        end
        if x>data(i)
            f_1(i)=(1/sgm)*exp((data(i)-x)/sgm);
        end
    end
end
value=sum(f_1);
end


function [a0]=MCC_vc_ECOS(n,N_n,c,epsilon,w)
G1=[n',-eye(N_n,N_n)];
G2=[-n',-eye(N_n,N_n)];
G3=[1 0 1 0 0 0;
    0 1 0 0 0 0;
    0 0 0 0 0 0;
    1 0 -1 0 0 0];
G3=[-G3,zeros(4,N_n)];
G = [G1;G2;G3];
G = sparse(G);
h1=c*ones(N_n,1);
h2=-c*ones(N_n,1);
h3=[0,0,epsilon,0]';

h = [h1;h2;h3];
dims.l = 2*N_n;
dims.q = 4;
C = [zeros(6,1); -w'];
opts = ecosoptimset('VERBOSE',0);
[x,~,~,~,~] = ecos(C,G,h,dims,opts);
a0=x(1:6);
end


