A = [0;1];
b = [-1;1];

params.A = A;
params.b = b;