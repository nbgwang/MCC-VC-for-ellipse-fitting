% This code is developed for coupled ellipse fitting without data association based on MCC-VC. The details can be found in 
% Wei Wang, Gang Wang, Chenlong Hu, and K. C. Ho, 
%��Robust Ellipse Fitting Based on Maximum Correntropy Criterion With Variable Center,�� 
%IEEE Transactions on Image Processing, Accepted for Publication, Apr. 2023.
%
% Note: This code requires to setup the ECOS toolbox before implementation.
% ECOS can be downloaded from: https://web.stanford.edu/~boyd/papers/ecos.html
%
% Wei Wang, Gang Wang, Chenlong Hu, and K. C. Ho,  Apr-18-2023
%
%       Copyright (C) 2023
%       Ningbo University, Ningbo 315211, China
%       wanggang@nbu.edu.cn

clc;clear;close all
z=1;%Number of scenes
It=50;%Number of iterations
V=1;%Number of Monte Carlo runs
N1=100;
N2=100;
N=N1+N2;
outlier_fix=40;
num=0;
tic
for outlier=40%Number of outliers  
    num=num+1
    rand('seed',10);
    h_all = 20*rand(z,1);
    k_all = 20*rand(z,1);
    b_all = 20*(2*rand(z,1)-ones(z,1))+30;
    mu_all = rand(z,1);
    sigma_all = 0.005*b_all;
    theta_all=90*(2*rand(z,1)-ones(z,1))/360*2*pi;
    alpha_true_all = cell(z,1);
    M_all= cell(z,1);
    M1_all= cell(z,1);
    MM_all= cell(z,1);
    MM1_all= cell(z,1);
    MMo_all= cell(z,1);
    MMo1_all= cell(z,1);
    randn('seed',160);   
    for i = 1:z
        a_all(i,1) =((50-b_all(i))/2)*(2*rand(1,1)-ones(1,1))+((60+b_all(i))/2);
        alpha_true_all{i} = rand(N,1)*2*pi;
        M_all{i} = randn(N,V);
        M1_all{i} = randn(N,V);
        MM_all{i} = b_all(i)*(2*rand(outlier_fix,V)-ones(outlier_fix,V));
        MM1_all{i} = b_all(i)*(2*rand(outlier_fix,V)-ones(outlier_fix,V));
        MMo_all{i} = b_all(i)*mu_all(i)*(2*rand(outlier_fix,V)-ones(outlier_fix,V));
        MMo1_all{i} = b_all(i)*mu_all(i)*(2*rand(outlier_fix,V)-ones(outlier_fix,V));
    end
    for ii=1:z %%Scene 2
        sigma=sigma_all(ii);
        h = h_all(ii);
        k = k_all(ii);
        a = a_all(ii);
        b = b_all(ii);
        theta=theta_all(ii);
        mu=mu_all(ii);
        noise1 = N1-outlier;
        noise2 = N2-outlier;
        alpha_true = alpha_true_all{ii};
        M = M_all{ii};
        M1 = M1_all{ii};
        MM = MM_all{ii};
        MM1 = MM1_all{ii};
        MMo = MMo_all{ii};
        MMo1 = MMo1_all{ii};
        alpha_true0 = 0:2*pi/2000:2*pi;
        Np = length(alpha_true0);
        
        for i=1:Np
            cos_alpha(i) = sqrt(1)*cos(alpha_true0(i));
            sin_alpha(i) = sqrt(1)*sin(alpha_true0(i));
            x1(i) = (a*cos_alpha(i)*cos(theta) - b*sin_alpha(i)*sin(theta)) + h;
            y1(i) = (a*cos_alpha(i)*sin(theta) + b*sin_alpha(i)*cos(theta)) + k;
            x2(i) = (a*mu*cos_alpha(i)*cos(theta) - b*mu*sin_alpha(i)*sin(theta)) + h;
            y2(i) = (a*mu*cos_alpha(i)*sin(theta) + b*mu*sin_alpha(i)*cos(theta)) + k;
        end
        
        for v=1:V         
            cos_alpha=[];sin_alpha=[];
            xx=[];yy=[];XX=[];YY=[];
            n1=[];n2=[];m1=[];m2=[];
            store=[];storetarget=[];
            data_points=[];G_e=[];G=[];G0=[];G1=[];
            
            for i=1:noise1
                nx = sigma*M(i,v);
                ny = sigma*M1(i,v);
                cos_alpha(i) = sqrt(1)*cos(alpha_true(i));
                sin_alpha(i) = sqrt(1)*sin(alpha_true(i));
                xx(i) = (a*cos_alpha(i)*cos(theta) - b*sin_alpha(i)*sin(theta)) + h+nx;
                yy(i) = (a*cos_alpha(i)*sin(theta) + b*sin_alpha(i)*cos(theta)) + k+ny;
            end
            
            for i=noise1+1:N1
                nx = sigma*M(i,v);
                ny = sigma*M1(i,v);
                Nx = MM(i-noise1,v);
                Ny = MM1(i-noise1,v);
                cos_alpha(i) = sqrt(1)*cos(alpha_true(i));
                sin_alpha(i) = sqrt(1)*sin(alpha_true(i));
                xx(i) = (a*cos_alpha(i)*cos(theta) - b*sin_alpha(i)*sin(theta)) + h+nx+Nx;
                yy(i) = (a*cos_alpha(i)*sin(theta) + b*sin_alpha(i)*cos(theta)) + k+ny+Ny;
            end
            
            for i=1:noise2
                nX = sigma*M(N1+i,v);
                nY = sigma*M1(N1+i,v);
                cos_alpha(i) = sqrt(1)*cos(alpha_true(N1+i));
                sin_alpha(i) = sqrt(1)*sin(alpha_true(N1+i));
                XX(i) = (a*mu*cos_alpha(i)*cos(theta) - b*mu*sin_alpha(i)*sin(theta)) + h+nX;
                YY(i) = (a*mu*cos_alpha(i)*sin(theta) + b*mu*sin_alpha(i)*cos(theta)) + k+nY;
            end
            
            for i=noise2+1:N2
                nX = sigma*M(N1+i,v);
                nY = sigma*M1(N1+i,v);
                NX = MMo(i-noise2,v);
                NY = MMo1(i-noise2,v);
                cos_alpha(i) = sqrt(1)*cos(alpha_true(N1+i));
                sin_alpha(i) = sqrt(1)*sin(alpha_true(N1+i));
                XX(i) = (a*mu*cos_alpha(i)*cos(theta) - b*mu*sin_alpha(i)*sin(theta)) + h+nX+NX;
                YY(i) = (a*mu*cos_alpha(i)*sin(theta) + b*mu*sin_alpha(i)*cos(theta)) + k+nY+NY;
            end
            
            X=[xx,XX]; Y=[yy,YY];
            
            for i = 1:N
                G_e(:,i)= [X(i)^2 X(i)*Y(i) Y(i)^2 X(i) Y(i) 1]';
            end
            
            [Qb]=data_association(G_e);%Data Association
                   
            num0=0;num1=0;num2=0;
            
            for i=1:N
                if(Qb(i,1)==1)
                    num1=num1+1;
                    G(:,i)= [X(i)^2 X(i)*Y(i) Y(i)^2 X(i) Y(i) 1 0]';
                else
                    num2=num2+1;
                    G(:,i)= [X(i)^2 X(i)*Y(i) Y(i)^2 X(i) Y(i) 0 1]';
                end
            end
            
            [p]=EF_MCCVC_LP_couple(G);
            
            [h_hat,k_hat,a_hat,b_hat,theta_hat,mu_hat]=Parameter_transformation(p);
            
            FitErr=((h_hat-h)^2+(k_hat-k)^2+(a_hat-a)^2+(b_hat-b)^2+(theta_hat-theta)^2+(mu_hat-mu)^2)
            
        end
    end
end

alpha_hat = 0:2*pi/2000:2*pi;
Np = length(alpha_hat);
for i=1:Np
x_inner(i) = (a_hat*mu_hat*cos(alpha_hat(i))*cos(theta_hat) - b_hat*mu_hat*sin(alpha_hat(i))*sin(theta_hat)) + h_hat;
y_inner(i) = (a_hat*mu_hat*cos(alpha_hat(i))*sin(theta_hat) + b_hat*mu_hat*sin(alpha_hat(i))*cos(theta_hat)) + k_hat;
end
for i=1:Np
x_outer(i) = (a_hat*cos(alpha_hat(i))*cos(theta_hat) - b_hat*sin(alpha_hat(i))*sin(theta_hat)) + h_hat;
y_outer(i) = (a_hat*cos(alpha_hat(i))*sin(theta_hat) + b_hat*sin(alpha_hat(i))*cos(theta_hat)) + k_hat;
end

figure
plot(X,Y,'k+','LineWidth',1.5);hold on;
plot(x_inner,y_inner,'m-','LineWidth',1.5);hold on;
plot(x_outer,y_outer,'b-','LineWidth',1.5);hold on;
legend('Data Points','Inner Ellipse','Outer Ellipse')
xlabel('xlabel');
ylabel('ylabel');
