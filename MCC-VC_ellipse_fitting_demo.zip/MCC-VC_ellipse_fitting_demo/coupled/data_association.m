function [Qb]=data_association(G_e)
N=size(G_e,2);
epsilon=1;
tao=[0;1];

[Q0]=data_association_ECOS(G_e,N,epsilon);
Qa=[Q0(:,2),Q0(:,1)];

Qb=Q0>(Qa);
end

function [Q0]=data_association_ECOS(G_e,N,epsilon)

G1=[zeros(N,N),eye(N,N),G_e',-eye(N,N)];h1 = zeros(N,1);

G2=[zeros(N,N),-eye(N,N),-G_e',-eye(N,N)];h2 = zeros(N,1);

G3_1 = -eye(2*N,2*N); G3_2 = zeros(2*N,N+6); G3_3 = zeros(N+6,2*N);G3_4 = zeros(N+6,N+6);
G3=[G3_1,G3_2;G3_3,G3_4];h3 = zeros(3*N+6,1);

G5 =[eye(N,N),eye(N,N),zeros(N,N+6)];h5 = ones(N,1);

G5 = sparse(G5);

G6_1 = [1 0 1 0 0 0 ;
       0 1 0 0 0 0 ;
       0 0 0 0 0 0 ;
       1 0 -1 0 0 0 ];

G6=[zeros(4,N),zeros(4,N),-G6_1,zeros(4,N)];h6 = [0,0,epsilon,0]';

G = [G1;G2;G3;G6];

G = sparse(G);

h = [h1;h2;h3;h6];

dims.l = length(h)-4;

dims.q = 4;

C = [zeros(2*N+6,1);ones(N,1)];

opts = ecosoptimset('VERBOSE',0);

[x,y,info,s,z] = ecos(C,G,h,dims,G5,h5,opts);

Q0(:,1)=x(1:N);

Q0(:,2)=x(N+1:2*N);

end


