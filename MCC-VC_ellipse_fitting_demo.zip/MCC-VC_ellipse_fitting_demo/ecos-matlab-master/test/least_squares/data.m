m = 10;
n = 5;
p = 3;
A = randn(m,n);
C = randn(p,n);
d = randn(p,1);


xtrue = randn(n,1);
b = A*xtrue + 0.1*randn(m,1);

e = rand;

params.A = A;
params.C = C;
params.d = d;
params.b = b;
params.e = e;