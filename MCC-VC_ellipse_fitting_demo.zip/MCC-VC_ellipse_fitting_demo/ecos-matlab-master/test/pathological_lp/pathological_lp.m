cvx_begin
    variable x
    minimize x
    A*x <= b
cvx_end