% parameters
q = 10;
r = 1;
p = 100;
a = 1.1;
b = 0.5;
x_0 = 1.0;

zero = 0;
one = 1;
one_over_q = 1/q;

params.q = q;
params.r = r;
params.p = p;
params.a = a;
params.b = b;
params.x_0 = x_0;
params.zero = zero;
params.one = one;
params.one_over_q = 1/q;
