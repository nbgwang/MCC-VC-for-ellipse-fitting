function [h_hat,k_hat,a_hat,b_hat,theta_hat,mu_hat]=Parameter_transformation (p)
% % ����ת��
A = p(1)/p(6);
B = p(2)/p(6);
C = p(3)/p(6);
D = p(4)/p(6);
E = p(5)/p(6);
% F = 1;
% delta=B^2-4*A*C
% mu_hat=1/(1-(p(7)-p(6)));
% ============================================================��theta����ֵ����չ
    theta_hat=(1/2)*atan2(-B,-(A-C));
% ============================================================
hk=inv([-2*A -B;-B -2*C])*[D;E];
h_hat=hk(1,:);
k_hat=hk(2,:);
a_hat=sqrt(([h_hat;k_hat]'*[A B/2;B/2  C]*[h_hat;k_hat]-1)/(A*(cos(theta_hat))^2+B*sin(theta_hat)*cos(theta_hat)+C*(sin(theta_hat))^2));
b_hat=sqrt(([h_hat;k_hat]'*[A B/2;B/2  C]*[h_hat;k_hat]-1)/(A*(sin(theta_hat))^2-B*sin(theta_hat)*cos(theta_hat)+C*(cos(theta_hat))^2));
% a_hat1=sqrt(2*(p(1)*h_hat^2+p(2)*h_hat*k_hat+p(3)*k_hat^2-p(6))/p(1)+p(3)-sqrt((p(1)-p(3))^2+p(2)^2))
% a_hat1=sqrt(([h_hat;k_hat]'*[p(1) p(2)/2;p(2)/2  p(3)]*[h_hat;k_hat]-p(6))/(p(1)*(cos(theta_hat))^2+p(2)*sin(theta_hat)*cos(theta_hat)+p(3)*(sin(theta_hat))^2));
A_hat = ((sin(theta_hat))^2/b_hat^2)+((cos(theta_hat))^2/a_hat^2);
mu_hat=sqrt(1-(p(7)-p(6))/(p(1)/A_hat));
% mu_hat=sqrt(1-alph/(p(1)/A_hat));
if(abs(a_hat)<abs(b_hat))
    theta_hat=(1/2)*atan2(B,(A-C));
% ============================================================
hk=inv([-2*A -B;-B -2*C])*[D;E];
h_hat=hk(1,:);
k_hat=hk(2,:);
a_hat=sqrt(([h_hat;k_hat]'*[A B/2;B/2  C]*[h_hat;k_hat]-1)/(A*(cos(theta_hat))^2+B*sin(theta_hat)*cos(theta_hat)+C*(sin(theta_hat))^2));
b_hat=sqrt(([h_hat;k_hat]'*[A B/2;B/2  C]*[h_hat;k_hat]-1)/(A*(sin(theta_hat))^2-B*sin(theta_hat)*cos(theta_hat)+C*(cos(theta_hat))^2));
% a_hat1=sqrt(2*(p(1)*h_hat^2+p(2)*h_hat*k_hat+p(3)*k_hat^2-p(6))/p(1)+p(3)-sqrt((p(1)-p(3))^2+p(2)^2))
A_hat = ((sin(theta_hat))^2/b_hat^2)+((cos(theta_hat))^2/a_hat^2);
mu_hat=sqrt(1-(p(7)-p(6))/(p(1)/A_hat));
% PP=p(1)/A_hat
end
end