function obj = CodeGen

obj.endpoint = 'http://forces.ethz.ch/CodeGen.asmx';
obj.wsdl = 'http://forces.ethz.ch/CodeGen.asmx?Wsdl';

obj = class(obj,'CodeGen');

