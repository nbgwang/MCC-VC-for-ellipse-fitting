l = -1;
u = 3;

params.l = l;
params.u = u;
