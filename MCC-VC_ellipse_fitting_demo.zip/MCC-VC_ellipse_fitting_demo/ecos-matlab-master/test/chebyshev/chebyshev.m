cvx_begin
    variable r(1)
    variable x(2)
    maximize ( r )
    a1'*x + r*norm(a1,2) <= b(1);
    a2'*x + r*norm(a2,2) <= b(2);
    a3'*x + r*norm(a3,2) <= b(3);
    a4'*x + r*norm(a4,2) <= b(4);
cvx_end